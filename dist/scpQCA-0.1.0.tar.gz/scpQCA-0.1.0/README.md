# scpQCA

This is a new and more powerful algorithm.

The source code could find in https://github.com/Kim-Q/scpQCA.git, please obey the Apache-2.0 license.
